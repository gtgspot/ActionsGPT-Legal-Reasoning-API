# Working Examples

Demonstrations of the discourse coherence architecture skill in both
PRE-WRITE and POST-AUDIT modes. Each example shows the skill's process
and output on realistic material.

---

## Example 1: PRE-WRITE Mode — Technical Proposal

**User request:** "Write a proposal recommending we migrate from a
monolithic architecture to microservices."

### Step 1: Intent Decomposition

```
Purpose:    Convince decision-makers to approve a microservices migration
Audience:   Engineering leadership + CTO (technical; budget authority)
Scope:      Architecture recommendation only — not implementation plan
Success:    Reader agrees migration is warranted and approves next phase
```

### Step 2: Claim Inventory

| ID | Claim | Type | Requires | Provides | Section |
|----|-------|------|----------|----------|---------|
| C1 | Current monolith has reached scaling limits | PREMISE | — | C3, C4 | §1 |
| C2 | Business growth projections require 5x current capacity within 18 months | EVIDENCE | — | C1 | §1 |
| C3 | Three architectural options exist: scale vertically, modular monolith, microservices | FRAMING | C1 | C4, C5, C6 | §2 |
| C4 | Vertical scaling buys 6 months at most before the same ceiling | PREMISE | C1, C3 | C7 | §2 |
| C5 | Modular monolith reduces coupling but doesn't solve deployment independence | PREMISE | C3 | C7 | §2 |
| C6 | Microservices enable independent scaling, deployment, and team ownership | PREMISE | C3 | C7 | §2 |
| C7 | Microservices is the only option that meets the 18-month capacity target | SYNTHESIS | C4, C5, C6 | C10 | §3 |
| C8 | Migration carries risks: distributed systems complexity, data consistency, team readiness | CONCESSION | C7 | C9 | §4 |
| C9 | Each risk has a proven mitigation: service mesh, event sourcing, phased rollout | REBUTTAL | C8 | C10 | §4 |
| C10 | Recommendation: approve Phase 1 discovery sprint (4 weeks, 2 engineers) | THESIS | C7, C9 | — | §5 |

### Step 3: Dependency Graph

```
C2 → C1 → C3 → C4 ─┐
                C3 → C5 ─┤→ C7 → C10
                C3 → C6 ─┘    ↑
                          C8 → C9 ┘
```

No orphans. No cycles. All paths lead to C10 (thesis).

### Step 4: Section Contracts

```
§1 — The Scaling Problem
  RECEIVES:  [nothing — opening section]
  ESTABLISHES: C1, C2
  DELIVERS:  Reader accepts that the monolith cannot meet future demand
  REGISTER:  Formal business
  THREADS:   Introduces T1 (scaling need)

§2 — Options Evaluated  
  RECEIVES:  Scaling problem is established and accepted
  ESTABLISHES: C3, C4, C5, C6
  DELIVERS:  Reader understands three options and their trade-offs
  REGISTER:  Technical (permitted — audience is engineering leadership)
  THREADS:   T1 (develops)

§3 — Why Microservices
  RECEIVES:  All three options and their trade-offs
  ESTABLISHES: C7
  DELIVERS:  Reader agrees microservices is the strongest option
  REGISTER:  Formal business (returning from technical)
  THREADS:   T1 (approaches resolution)

§4 — Risks and Mitigations
  RECEIVES:  Microservices recommendation
  ESTABLISHES: C8, C9
  DELIVERS:  Reader's risk concerns are addressed
  REGISTER:  Formal business
  THREADS:   Introduces T2 (risk), resolves T2

§5 — Recommendation
  RECEIVES:  Problem established, solution validated, risks mitigated
  ESTABLISHES: C10
  DELIVERS:  Reader has a concrete next step to approve
  REGISTER:  Formal business (directive)
  THREADS:   Resolves T1
```

### Step 5: Thread Map

```
T1 (scaling need): §1 (intro) → §2 (develops) → §3 (approaches resolution) → §5 (resolves)
T2 (risk):         §4 (intro + resolves — contained thread)
```

No dropped threads. No gaps >1 section.

### Step 6: Transition Map

```
§1 → §2: CAUSE-EFFECT
  "Given this ceiling, three architectural paths forward exist."

§2 → §3: INFERENCE
  "Of these three options, only one meets the 18-month target."

§3 → §4: CONCESSION
  "This recommendation is not without risk."

§4 → §5: INFERENCE
  "With these mitigations in place, the path forward is clear."
```

### Step 7: Validation

```
[✓] HC-1: No orphaned claims — all nodes connected
[✓] HC-2: No unresolved dependencies — all requires satisfied
[✓] HC-3: No implicit contradictions
[✓] HC-4: Section contracts satisfied — all receives trace to prior delivers
[✓] HC-5: Threads complete — T1 resolved §5, T2 resolved §4
[✓] HC-6: Thesis connectivity — all nodes reachable from C10
[✓] HC-7: No circular dependencies — DAG confirmed
[✓] SC-1: Max 2 threads per section — satisfied
[✓] SC-3: All transitions carry structural load
[✓] SC-7: Concession (C8) paired with Rebuttal (C9)

RESULT: PASS — proceed to generation
```

---

## Example 2: POST-AUDIT Mode — Incoherent Business Email

**User submits the following text for coherence audit:**

> Our Q3 results exceeded expectations with 23% revenue growth. The
> marketing team launched three new campaigns targeting enterprise
> customers. However, customer churn increased by 4% compared to Q2.
> We've also been investing heavily in our AI capabilities. As a result,
> our competitive position has strengthened significantly. The board
> has approved a new hiring plan for Q4. Additionally, our NPS score
> dropped from 72 to 61. In conclusion, Q3 was a strong quarter that
> positions us well for the year ahead.

### Reconstructed Claim Graph

| ID | Claim | Type | Actual Relation to Next |
|----|-------|------|------------------------|
| C1 | Q3 revenue grew 23% | EVIDENCE | → C8 (supposed to support thesis) |
| C2 | Marketing launched 3 enterprise campaigns | EVIDENCE | NONE — orphaned |
| C3 | Churn increased 4% vs Q2 | EVIDENCE | CONTRADICTS C8 |
| C4 | Investing in AI capabilities | CLAIM | NONE — orphaned |
| C5 | Competitive position strengthened | CLAIM | FALSE CAUSATION from C4 |
| C6 | Board approved Q4 hiring | CLAIM | NONE — orphaned |
| C7 | NPS dropped from 72 to 61 | EVIDENCE | CONTRADICTS C8 |
| C8 | Q3 was strong, positions us well | THESIS | UNSUPPORTED |

### Failures Identified

**F-06: Synthetic Coherence (Critical)**
Location: Entire document.
The email uses "However", "As a result", "Additionally", "In conclusion"
to create the appearance of logical flow. But the claims have no actual
argumentative structure — they are a list of facts with connectives
stapled on. Reordering any paragraph would not change the document's
meaning. This is the defining signature of synthetic coherence.

**F-02: Phantom Causation (Critical)**
Location: "We've also been investing heavily in our AI capabilities.
As a result, our competitive position has strengthened significantly."
"As a result" implies AI investment caused competitive strengthening.
No evidence supports this causal claim. The relation is either
TEMPORAL (these things happened in the same quarter) or the causation
needs evidence.

**HC-3: Implicit Contradiction (Critical)**
Location: C3 + C7 vs C8.
Churn up 4% and NPS down 11 points both contradict "Q3 was a strong
quarter." The document acknowledges negative signals but reaches a
positive conclusion without addressing the contradiction. This requires
either CONCESSION + REBUTTAL (acknowledge the negatives, explain why
the positives outweigh) or a qualified thesis.

**HC-1: Orphaned Claims (Moderate)**
Location: C2, C4, C6.
Marketing campaigns, AI investment, and board hiring approval are stated
but connect to nothing. They neither support nor undermine the thesis.
They exist because the author had these facts and included them — not
because the argument needs them.

**F-03: Orphaned Setup (Minor)**
Location: C2.
"Three new campaigns targeting enterprise customers" — the number "three"
and the enterprise focus suggest these matter, but the email never says
what they achieved, whether they relate to the revenue growth, or how
they connect to churn.

### Improved Version

```
Q3 delivered 23% revenue growth, exceeding our target by 8 points.

This growth came despite a 4% increase in customer churn and an NPS
decline from 72 to 61. Both metrics signal retention pressure that we
need to address — but they haven't yet offset the top-line momentum
driven by enterprise expansion.

Three new enterprise-focused campaigns launched in Q3 contributed
approximately $2.1M in new pipeline. The board has approved an expanded
Q4 hiring plan to sustain this acquisition trajectory while we invest
in reducing churn through our AI-powered customer success tooling.

Net assessment: Q3's revenue strength is real, but the churn and NPS
trends require active intervention in Q4 to prevent them from eroding
the gains.
```

### Changes Made

| Original Problem | Fix Applied |
|---|---|
| Synthetic coherence — connectives without logic | Restructured into three-part argument: positive signal → negative signal with CONCESSION → net assessment |
| Phantom causation on AI investment | Connected AI investment to a specific outcome (customer success tooling for churn reduction) |
| Contradiction between negatives and positive thesis | Made thesis conditional: "strength is real, but..." — CONCESSION + QUALIFICATION |
| Orphaned campaigns claim | Connected to revenue with specific pipeline figure |
| Orphaned hiring plan | Connected to sustaining acquisition trajectory |
| Orphaned AI investment | Connected to churn reduction strategy |

---

## Example 3: PRE-WRITE Self-Interruption

**Scenario:** Claude is generating a legal submission and detects
coherence degradation mid-output.

### What Happened

Claude is writing a submission arguing that a POFT device result should
be excluded. The coherence graph has three threads:

- T1: Device precondition failure (s.55E)
- T2: Chain of custody gap
- T3: Non-contemporaneous record-keeping

At §4 (Chain of custody), Claude writes:

> "The five-day gap between sample collection and laboratory receipt
> raises serious questions about the integrity of the sample. **The
> officer's failure to follow standard operating procedure is further
> evidenced by the non-contemporaneous CAD entry.**"

### Self-Interruption Trigger

The bolded sentence introduces a T3 claim (non-contemporaneous records)
inside a T2 section (chain of custody). The section contract for §4
declares only T2 as active. T3 is scheduled for §5.

This violates SC-1 (maximum 2 active threads per section) and breaks
the thread braid — T3 is now partially introduced in §4, which will
make §5's introduction of T3 redundant or confusing.

### Correction

Claude pauses, flags the thread bleed, and revises:

> "The five-day gap between sample collection and laboratory receipt
> raises serious questions about the integrity of the sample. No
> documentation accounts for the sample's location or handling during
> this period."

The non-contemporaneous CAD entry point is held for §5 where it belongs,
preserving the thread braid and section contract.

---

## Usage Notes

These examples demonstrate three key patterns:

1. **PRE-WRITE builds the architecture before any prose exists.** The
   proposal example shows how a coherence graph prevents the common
   failure of "writing yourself into a corner" where §4 needs something
   §2 never established.

2. **POST-AUDIT reverse-engineers the architecture to find failures.**
   The business email example shows how synthetic coherence — the most
   common failure in real-world writing — is detected by testing whether
   the connectives match actual logical relations.

3. **Self-interruption catches thread bleed during generation.** The
   legal submission example shows how the section contract system
   prevents threads from tangling when the writer is deep in a section
   and a related thought from another thread intrudes.
