# Discourse Relations Taxonomy

Every edge in the coherence graph must carry one of these typed relations.
Using an untyped connection ("and then", "also", "additionally") is a
coherence failure — it means the actual relationship hasn't been identified.

---

## Relation Categories

### 1. Causal Relations

The source node *causes* or *explains* the target node.

| Relation | Definition | Signal Words | Example |
|---|---|---|---|
| CAUSE-EFFECT | Source directly causes target | "because", "therefore", "as a result", "consequently" | "Costs increased (C1) → Prices rose (C2)" |
| EFFECT-CAUSE | Target explains source (reverse causal) | "this happened because", "the reason is" | "Prices rose (C1) ← Costs increased (C2)" |
| ENABLES | Source creates conditions for target (not guaranteed) | "allows", "makes possible", "paves the way" | "API exists (C1) → Integration is feasible (C2)" |
| PREVENTS | Source blocks target from occurring | "prevents", "blocks", "makes impossible" | "Encryption (C1) → Interception fails (C2)" |
| PURPOSE | Target is the goal motivating source | "in order to", "so that", "to achieve" | "We restructured (C1) → To reduce latency (C2)" |

### 2. Logical Relations

The source node provides logical support for the target.

| Relation | Definition | Signal Words | Example |
|---|---|---|---|
| EVIDENCE | Source provides specific data supporting target | "for example", "specifically", "data shows" | "Survey results (C1) → Users prefer X (C2)" |
| JUSTIFICATION | Source provides reasoning for target claim | "since", "given that", "on the grounds that" | "Statutory requirement (C1) → Procedure is mandatory (C2)" |
| INFERENCE | Target is derived by reasoning from source | "thus", "it follows that", "we can conclude" | "Premises A+B (C1) → Conclusion C (C2)" |
| GENERALISATION | Target is a broader principle drawn from source | "in general", "broadly", "this suggests" | "Three case studies (C1) → Pattern holds generally (C2)" |
| INSTANTIATION | Target is a specific case of source | "for instance", "one example", "in this case" | "General principle (C1) → Specific application (C2)" |

### 3. Contrastive Relations

The source and target are in tension or opposition.

| Relation | Definition | Signal Words | Example |
|---|---|---|---|
| CONTRAST | Source and target differ on a relevant dimension | "whereas", "while", "by contrast", "on the other hand" | "Approach A is fast (C1) vs. Approach B is thorough (C2)" |
| CONCESSION | Source acknowledges a point that opposes the argument direction | "although", "despite", "admittedly", "granted" | "Cost is high (C1) — but value justifies it (C2)" |
| REBUTTAL | Source directly counters a preceding concession or objection | "however", "nevertheless", "but in fact" | "Objection X (C1) → Rebuttal to X (C2)" |
| CONTRADICTION | Source and target cannot both be true | [should not appear in well-formed arguments] | Flag as coherence failure if found |
| QUALIFICATION | Target limits the scope or certainty of source | "except when", "unless", "with the caveat that" | "Rule applies generally (C1) → Except in cases of X (C2)" |

### 4. Elaborative Relations

The target develops, clarifies, or refines the source.

| Relation | Definition | Signal Words | Example |
|---|---|---|---|
| ELABORATION | Target adds detail to source without changing its claim | "specifically", "in particular", "more precisely" | "System is fast (C1) → Handles 10k req/s (C2)" |
| RESTATEMENT | Target says the same thing as source in different words | "in other words", "put differently", "that is" | [Use sparingly — often indicates the first statement wasn't clear enough] |
| SPECIFICATION | Target narrows source to a particular case or parameter | "namely", "in the case of", "when applied to" | "The policy covers employees (C1) → Specifically, full-time staff (C2)" |
| DEFINITION | Target defines a term or concept introduced in source | "defined as", "meaning", "refers to" | "Misfeasance (C1) → Defined as deliberate misuse of power (C2)" |
| SUMMARY | Target condenses multiple prior claims | "in summary", "to conclude", "the key point is" | "Claims C1-C5 → Summary synthesis (C6)" |

### 5. Structural Relations

Relations that organise the document rather than advancing the argument.

| Relation | Definition | Signal Words | Example |
|---|---|---|---|
| SEQUENCE | Source must precede target in temporal or procedural order | "first", "then", "next", "after" | "Step 1 (C1) → Step 2 (C2)" |
| PARALLEL | Source and target are coordinate elements at the same level | "similarly", "likewise", "in the same way" | "Benefit A (C1) ∥ Benefit B (C2)" |
| BACKGROUND | Source provides context the reader needs before target | "historically", "for context", "to understand this" | "Industry context (C1) → Current problem (C2)" |
| FRAME_SHIFT | Target changes the interpretive lens established by source | "from a different perspective", "viewed alternatively" | "Technical view (C1) → Commercial view (C2)" |
| TOPIC_SHIFT | Target moves to a new subject | [Should be mediated by a TRANSITION node] | Flag if unmediated — likely a coherence break |

---

## Relation Selection Rules

1. **Every edge gets exactly one relation.** If two relations seem to apply,
   choose the one that is load-bearing for the argument. Note the secondary
   relation in the edge metadata if needed.

2. **Signal words are diagnostic, not definitive.** "However" often signals
   CONTRAST or CONCESSION, but writers misuse it constantly. Classify by the
   *actual* logical relationship, not the connective used. A mismatch between
   connective and actual relation is itself a coherence defect.

3. **Implicit relations must be made explicit.** If two claims sit adjacent
   in prose with no connective and no clear logical link, the relation is
   implicit. Classify it by inference, mark `explicit: false`, and flag for
   review.

4. **CONTRADICTION is always a failure** in argumentative or expository text.
   If two claims contradict each other, one must be removed, qualified, or
   the contradiction must be explicitly addressed (which converts it to
   CONCESSION + REBUTTAL).

5. **RESTATEMENT is a smell.** If the same claim needs to be said twice in
   different words, the first statement likely wasn't clear. Consider
   rewriting the first instead of adding a restatement.

6. **TOPIC_SHIFT without a TRANSITION node is a coherence break.** Every
   subject change must be mediated — the reader needs a bridge.

---

## Relation Strength Assessment

For each edge, assess how load-bearing the relation is:

- **NECESSARY:** Remove this edge and the target claim becomes
  incomprehensible or unsupported. The argument structurally depends
  on this connection.
- **SUPPORTING:** The target is strengthened by this edge but could
  survive without it. The reader can fill the gap with reasonable
  inference.
- **WEAK:** The connection is cosmetic or habitual. "As mentioned
  earlier" when the earlier mention isn't actually needed for the
  current point. Weak edges should be removed or strengthened.

---

## Common Misclassification Patterns

| Writer Uses | Actual Relation | Why It Matters |
|---|---|---|
| "Therefore" | PARALLEL (no causal link exists) | Creates phantom causation — reader infers a logical chain that isn't there |
| "However" | ELABORATION (no actual contrast) | Reader expects a counterpoint that never arrives |
| "Similarly" | CONTRAST (the cases actually differ) | Reader misses the difference because the framing suppresses it |
| "As a result" | SEQUENCE (temporal, not causal) | Reader infers causation from mere temporal ordering |
| "In conclusion" | TOPIC_SHIFT (new material introduced) | Reader expects synthesis but gets new claims |
| No connective | Any relation | Forces reader to guess — the most common coherence failure |
