---
name: discourse-coherence-architecture
description: >
  Coherence planning engine for long-form writing. Builds a discourse
  coherence graph before prose — mapping claims, dependencies, thread
  continuity, and section contracts. Detects and prevents: thread drift,
  implicit contradictions, orphaned claims, unsupported transitions,
  register breaks, and premise-conclusion disconnects. Two modes:
  PRE-WRITE (plan coherence architecture before drafting) and POST-AUDIT
  (scan existing text for coherence failures). Trigger on: long-form
  writing, report drafting, essay writing, document planning, "plan this
  document", multi-section writing, "check coherence", "audit this
  document", "why does this feel disjointed", thread mapping, argument
  architecture, document structure, discourse planning, prose architecture,
  "build a coherence graph", section dependencies, claim mapping, any
  writing task over 1000 words, any multi-section deliverable, or when
  Claude detects its own output losing thread coherence.
---

# Discourse Coherence Architecture

Forces architectural planning before prose generation. Without this,
long-form output degrades through thread drift, implicit contradiction,
and transition failures that compound across sections.

## Why This Skill Exists

Claude's default generation is sequential — each paragraph conditions on
the previous, not on the document's architectural intent. This causes
three systemic failures in long-form output:

1. **Thread drift:** A framing established on page one subtly shifts by
   page three because no structure enforces consistency
2. **Phantom transitions:** "Therefore" and "as a result" imply logical
   connections that don't actually hold between the preceding and
   following content
3. **Orphaned claims:** An assertion appears mid-document with no prior
   setup and no subsequent development — it connects to nothing

The fix is structural: build the coherence graph *before* writing, then
write *to* the graph.

## Activation Protocol

1. Read this file completely
2. Determine mode: PRE-WRITE or POST-AUDIT
3. Load relevant L3 resources (see progressive disclosure pointers below)
4. Execute the appropriate workflow
5. Validate output against constraints (see `constraints/`)

### Progressive Disclosure — L3 Resources

| Resource | Path | Load When |
|---|---|---|
| Graph schema and node types | `schemas/coherence-graph-schema.md` | Every activation — defines the graph structure |
| Discourse relation taxonomy | `references/discourse-relations.md` | When classifying connections between sections |
| Coherence techniques | `techniques/coherence-techniques.md` | PRE-WRITE mode — planning tools |
| Constraint rules | `constraints/coherence-constraints.md` | Validation phase — both modes |
| Worked examples | `working-examples/examples.md` | First use, calibration, or when output quality is uncertain |

---

## Mode Detection

| Signal | Mode |
|---|---|
| User asks to write, draft, plan, outline, or structure a document | PRE-WRITE |
| User pastes existing text and asks to check, audit, review, or fix coherence | POST-AUDIT |
| Claude is mid-generation and detects its own coherence degrading | PRE-WRITE (pause, rebuild graph, resume) |
| Ambiguous | PRE-WRITE — planning is always safer than retrofitting |

---

## PRE-WRITE Mode — Coherence Graph Construction

Before writing any prose, build the coherence graph. This is the
architectural blueprint. No prose until the graph is complete.

### Step 1: Intent Decomposition

Parse the user's request into:
- **Document purpose:** What should the reader know, believe, or do after reading?
- **Audience:** Who reads this? What do they already know?
- **Scope boundary:** What is explicitly out of scope?
- **Success criteria:** How would the user evaluate whether this document works?

### Step 2: Claim Inventory

List every discrete claim, argument, or information unit the document
must contain. Each becomes a node in the coherence graph.

For each claim node, record:
- `claim_id`: Unique identifier (C1, C2, ...)
- `content`: The claim in one sentence
- `type`: THESIS | PREMISE | EVIDENCE | SYNTHESIS | TRANSITION | FRAMING
- `requires`: List of claim_ids this claim depends on (must appear before it)
- `provides`: What downstream claims need from this one
- `register`: The tonal register this claim operates in
- `section`: Which document section this belongs to

See `schemas/coherence-graph-schema.md` for the full node schema.

### Step 3: Dependency Mapping

Draw edges between claim nodes. Every edge must have an explicit
discourse relation (see `references/discourse-relations.md`).

Test each edge: "If I removed the source node, would the target node
still make sense to the reader?" If yes, the dependency is cosmetic,
not structural — mark it as weak.

### Step 4: Section Contract Definition

Each section of the document operates under a contract:

- **Receives:** What the reader must already understand when entering
  this section (inherited from previous sections)
- **Establishes:** What new claims or framing this section introduces
- **Delivers:** What the next section can assume the reader now knows
- **Register:** The tonal register for this section
- **Coherence obligations:** Which threads from earlier sections must be
  maintained, advanced, or resolved here

If a section's "receives" list includes items not in any prior section's
"delivers" list — that's a coherence gap. Fix the graph before writing.

### Step 5: Thread Continuity Verification

Trace each major thread (argument line, narrative arc, conceptual frame)
from its introduction through every section where it appears to its
resolution.

Flag:
- **Dropped threads:** Introduced but never resolved
- **Zombie threads:** Resolved but then referenced again as if still open
- **Thread collisions:** Two threads making incompatible claims about
  the same subject
- **Orphan threads:** Appearing mid-document with no introduction

### Step 6: Transition Audit

For every section boundary, verify the transition:
- Does the last sentence of section N logically connect to the first
  sentence of section N+1?
- Is the discourse relation between sections explicit and accurate?
- Would removing the transition sentence break the reader's comprehension?
  (If no, the transition is decorative — either strengthen it or cut it)

See `techniques/coherence-techniques.md` for transition patterns.

### Step 7: Graph Validation

Before writing, validate the complete graph against
`constraints/coherence-constraints.md`. Every constraint must pass.

### Step 8: Generate Prose

Write to the graph. Each section follows its contract. Each paragraph
advances a claim node. Each transition enacts a mapped discourse relation.

During generation, maintain a running checklist:
- [ ] Current section's "receives" items are all established
- [ ] Every claim in this section has its dependencies met
- [ ] Register is consistent with section contract
- [ ] No new claims introduced that aren't in the graph
- [ ] Thread continuity maintained for all active threads

If generation introduces a claim not in the graph — stop. Either add it
to the graph with proper dependency mapping, or remove it from the prose.

---

## POST-AUDIT Mode — Coherence Failure Detection

When auditing existing text, reverse-engineer the coherence graph from
the prose, then test it for failures.

### Step 1: Section Segmentation

Divide the text into logical sections (by headers, topic shifts, or
paragraph clusters).

### Step 2: Claim Extraction

Extract every discrete claim from each section. Record as claim nodes
per the schema.

### Step 3: Dependency Reconstruction

For each claim, identify what it depends on and what depends on it.
Map the discourse relations between adjacent claims.

### Step 4: Failure Scan

Apply each failure type from the taxonomy:

| Failure Type | What To Look For |
|---|---|
| **Implicit contradiction** | Two claims that cannot both be true, separated by enough text that the contradiction isn't obvious |
| **Thread drift** | A concept introduced with one framing that shifts meaning across sections without acknowledgment |
| **Phantom transition** | A connective ("therefore", "consequently", "as a result") where the logical relationship doesn't hold |
| **Orphaned claim** | A claim with no setup and no development — it connects to nothing |
| **Dropped thread** | A thread introduced but never resolved or explicitly set aside |
| **Register break** | A sudden shift in formality, technicality, or tone without rhetorical justification |
| **Dependency inversion** | A claim that appears before the premises it depends on |
| **Circular reasoning** | A claim whose support chain traces back to itself |
| **Scope violation** | Content that exceeds the document's stated or implied scope |

### Step 5: Audit Report

For each failure found:
- Location (section, paragraph, sentence)
- Failure type (from taxonomy)
- What specifically fails and why
- Proposed fix (restructure, add bridging claim, remove, reorder)
- Impact if unfixed (minor readability issue → structural argument failure)

---

## Output Formats

### Coherence Graph (PRE-WRITE)

```
## Coherence Graph: [Document Title]

### Document Intent
Purpose: [one sentence]
Audience: [who]
Success: [criteria]

### Claim Inventory
| ID | Claim | Type | Requires | Provides | Section |
|----|-------|------|----------|----------|---------|
| C1 | ...   | THESIS | — | C2, C3 | §1 |
| C2 | ...   | PREMISE | C1 | C4 | §2 |

### Section Contracts
**§1 — [Title]**
- Receives: [nothing — opening section]
- Establishes: C1, C3
- Delivers: Reader understands [X]
- Register: [formal/technical/narrative]
- Threads: Introduces Thread A

### Thread Map
Thread A: §1 (intro) → §3 (develops) → §5 (resolves)
Thread B: §2 (intro) → §4 (develops) → §6 (resolves)

### Transition Map
§1 → §2: [discourse relation] — [bridging logic]
§2 → §3: [discourse relation] — [bridging logic]

### Validation: [PASS / FAIL with details]
```

### Audit Report (POST-AUDIT)

```
## Coherence Audit: [Document Title/Description]

### Failures Found: [N]

**Failure 1**
- Type: [from taxonomy]
- Location: §[N], paragraph [N]
- Description: [what fails]
- Fix: [specific remediation]
- Impact: [severity]

### Reconstructed Graph
[Graph showing actual structure with failures marked]

### Remediation Priority
1. [Most impactful fix]
2. ...
```

---

## Self-Interruption Protocol

If Claude is generating long-form output *without* this skill having
been triggered, and detects any of these signals in its own output:

- Writing "however" or "on the other hand" without a genuine contrast
- Using "as mentioned earlier" when the earlier mention doesn't exist
  or said something different
- Starting a paragraph with a transition word that doesn't accurately
  describe the relationship to the previous paragraph
- Introducing a concept that contradicts a framing established earlier
  in the same response

Then: **pause generation**, acknowledge the coherence risk, and either
rebuild the graph for the remaining sections or flag the inconsistency
to the user.

---

## Operating Rules

- Never generate prose longer than 500 words without a coherence graph
  (even a minimal one)
- The graph is the authority — if prose contradicts the graph, fix the
  prose, not the graph (unless the graph itself is wrong, in which case
  update it explicitly)
- Every section transition must map to a discourse relation — "and then"
  is not a relation
- Register consistency is enforced per-section, not per-document (shifts
  are permitted but must be deliberate and mapped)
- POST-AUDIT mode always produces an audit report — never just "this
  looks fine"
- When the user says "just write it," build a minimal graph silently
  and write to it — don't skip the architecture
