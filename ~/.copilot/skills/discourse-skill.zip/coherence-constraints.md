# Coherence Constraints

Hard rules, soft rules, and failure mode catalogue for discourse coherence
validation. Applied in Step 7 of PRE-WRITE mode and Step 4 of POST-AUDIT
mode.

---

## Hard Constraints (Must Pass)

Violation of any hard constraint blocks prose generation. The graph must
be repaired before writing proceeds.

### HC-1: No Orphaned Claims
Every claim node must have at least one inbound or outbound edge. A claim
that connects to nothing does not belong in the document.

**Test:** Scan all nodes. Any node with zero edges → FAIL.
**Fix:** Connect to the graph or remove.

### HC-2: No Unresolved Dependencies
If claim C2 lists C1 in its `requires` field, C1 must appear in the graph
and must be ordered before C2 in the document's reading sequence.

**Test:** For each node, verify all `requires` entries exist and precede it.
**Fix:** Add missing dependency, reorder sections, or remove the requirement.

### HC-3: No Implicit Contradictions
No two claims in the graph may contradict each other unless the
contradiction is explicitly addressed through CONCESSION + REBUTTAL.

**Test:** Compare every claim pair for logical compatibility.
**Fix:** Remove one claim, qualify one claim, or add an explicit
CONCESSION → REBUTTAL chain.

### HC-4: Section Contract Satisfaction
Every item in a section's `receives` list must appear in a prior section's
`delivers` list. No section may assume knowledge the document hasn't
established.

**Test:** Trace each `receives` item backward. If no prior section
delivers it → FAIL.
**Fix:** Add the missing content to a prior section or move the dependent
section later.

### HC-5: Thread Completeness
Every thread must be either resolved or explicitly marked UNRESOLVED with
justification. Silently dropped threads are structural failures.

**Test:** Trace each thread from introduction through development to
resolution. If a thread has no resolution and no UNRESOLVED mark → FAIL.
**Fix:** Add a resolution section, or mark UNRESOLVED with explanation of
why this is acceptable.

### HC-6: Thesis Connectivity
Every claim in the graph must be reachable from at least one THESIS node
through a chain of typed discourse relations. If a claim exists that serves
no thesis — it doesn't belong.

**Test:** Breadth-first traversal from each THESIS node. Any unreached
claim → FAIL.
**Fix:** Connect to the thesis chain or remove.

### HC-7: No Circular Dependencies
The dependency graph must be a DAG (directed acyclic graph). Circular
reasoning — where A depends on B which depends on A — is always a
structural failure.

**Test:** Topological sort. If sort fails → cycle exists → FAIL.
**Fix:** Identify the cycle, determine which edge is the weakest, break it.

---

## Soft Constraints (Should Pass)

Violations degrade quality but don't block generation. Flag in the
coherence graph with a warning.

### SC-1: Maximum Two Active Threads Per Section
Sections carrying three or more threads simultaneously risk incoherence.
The reader loses track of which argument is being advanced.

**Warning threshold:** ≥3 active threads in a single section.
**Remediation:** Split the section or pause a thread with explicit
signalling.

### SC-2: Thread Gap Limit
A thread should not skip more than one consecutive section without
acknowledgment. Readers forget threads that disappear for too long.

**Warning threshold:** Thread absent for >1 section without a "we will
return to X" marker.
**Remediation:** Add a continuity marker or restructure to reduce the gap.

### SC-3: Transition Structural Load
Every section transition should carry structural load — it should advance
the argument, not just signal a topic change.

**Warning threshold:** Transition node contains no substantive claim
(pure connective tissue: "Moving on to...", "Next, we consider...").
**Remediation:** Rewrite transition using the three-part pattern (Anchor →
Bridge → Launch). See techniques/coherence-techniques.md, Technique 4.

### SC-4: Evidence Distribution
EVIDENCE nodes should be distributed across sections proportional to the
weight of the claims they support. A section making strong claims with no
evidence is underconstrained. A section with heavy evidence but weak claims
is wasted effort.

**Warning threshold:** Any STRUCTURAL claim with zero EVIDENCE nodes
supporting it.
**Remediation:** Add evidence or downgrade the claim's weight.

### SC-5: Register Consistency
Register should not shift within a section unless the shift is declared
in the section contract and limited to ≤2 sentences.

**Warning threshold:** Register marker mismatch detected within a section.
**Remediation:** Rewrite mismatched sentences to conform to declared
register, or declare the shift explicitly.

### SC-6: Decorative Node Density
If more than 30% of a document's claim nodes are DECORATIVE weight, the
document likely contains significant bloat.

**Warning threshold:** >30% DECORATIVE nodes.
**Remediation:** Review each decorative node for value. Cut, merge, or
upgrade to SUPPORTING.

### SC-7: Concession-Rebuttal Balance
Every CONCESSION node should have a paired REBUTTAL node. An unrebutted
concession weakens the argument without recovery. Multiple concessions
in sequence without rebuttals creates a pattern of retreat.

**Warning threshold:** CONCESSION node with no REBUTTAL pairing.
**Remediation:** Add rebuttal, remove concession, or restructure as
QUALIFICATION instead.

---

## Failure Mode Catalogue

Known coherence failure patterns. Use this catalogue during POST-AUDIT
mode to systematically scan for each type.

### F-01: Thread Drift
**Description:** A concept introduced with one meaning gradually shifts
to a different meaning across the document without acknowledgment.
**Example:** "Efficiency" introduced as computational efficiency (§1),
used as cost efficiency (§3), used as time efficiency (§5) — each valid
individually but collectively incoherent.
**Detection:** Track each significant term's operational definition at
point of introduction. Flag any instance where the same term is used with
a different operational definition.
**Impact:** Reader forms an understanding in §1 that §5 quietly violates.
The document appears to be about one thing but is actually about three.

### F-02: Phantom Causation
**Description:** A causal connective ("therefore", "as a result",
"consequently") appears between claims that have no causal relationship.
**Example:** "The team completed training. Therefore, the project shipped
on time." (Training may not have caused on-time delivery.)
**Detection:** For every causal connective, test: if the first claim were
false, would the second claim necessarily not follow? If the second could
still hold, the causation is phantom.
**Impact:** Reader infers a causal mechanism that doesn't exist, leading
to incorrect mental models.

### F-03: Orphaned Setup
**Description:** A claim appears early in the document that clearly sets
up a later payoff — but the payoff never arrives.
**Example:** §1 introduces "the three key risk factors" then only
discusses two throughout the document.
**Detection:** Scan for numeric commitments ("three reasons", "two
approaches"), enumerated lists, and forward-references ("as we will see").
Verify each is fulfilled.
**Impact:** Reader keeps waiting for the missing element, creating
cognitive load that distracts from the content that's actually there.

### F-04: Dependency Inversion
**Description:** A claim appears before the premises that would make it
comprehensible. The reader encounters a conclusion before the evidence.
**Example:** §2 states "the optimal architecture is microservices" before
§3 presents the evaluation criteria and analysis that lead to this
conclusion.
**Detection:** For each claim, check: would a reader encountering this
claim for the first time have sufficient context from prior content to
understand and evaluate it?
**Impact:** Reader must either accept the claim on authority (undermining
the argument's logic) or mentally reorder the document.

### F-05: Register Whiplash
**Description:** Abrupt, unjustified register shifts that break the
reader's engagement.
**Example:** A formal technical document suddenly uses "Basically, it's
kind of like..." then returns to formal register without transition.
**Detection:** Flag sentences whose register markers differ from the
section's declared register.
**Impact:** Reader loses trust in the author's control of the material.

### F-06: Synthetic Coherence
**Description:** The document uses transition words to create the
appearance of logical flow, but the underlying structure has no actual
logical progression. Each section could be reordered without loss.
**Example:** "Furthermore..." "Additionally..." "Moreover..." connecting
sections that are actually a list, not an argument.
**Detection:** Test: could these sections be reordered without changing
the document's meaning? If yes, the coherence is synthetic.
**Impact:** Reader follows a path that feels structured but actually
leads nowhere specific. The document has shape but no direction.

### F-07: Scope Creep
**Description:** The document gradually expands beyond its stated or
implied scope, introducing claims that don't serve the thesis.
**Detection:** For each claim node, test against the document's stated
purpose: does this claim advance the purpose? If the answer requires
more than one logical step to connect — it's likely scope creep.
**Impact:** Document becomes unfocused. Reader loses the through-line
and finishes without a clear takeaway.

### F-08: False Resolution
**Description:** A thread appears to be resolved but the resolution
doesn't actually follow from the development. The conclusion is asserted
rather than derived.
**Detection:** For each thread resolution, trace the logical chain from
development to resolution. Does the resolution follow from the preceding
content, or is it merely stated after it?
**Impact:** Reader senses the conclusion is unearned. The argument
"doesn't land" even though all the pieces appear to be present.
