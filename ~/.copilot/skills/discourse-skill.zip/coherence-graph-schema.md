# Coherence Graph Schema

Formal structure for discourse coherence graphs. Every graph built by the
skill must conform to this schema. Deviations cause silent coherence failures.

---

## Node Schema — Claim Nodes

Every discrete claim in the document is a node.

```yaml
claim_node:
  claim_id: string        # Unique: C1, C2, ... Sequential within document
  content: string          # The claim in one declarative sentence
  type: enum               # See Claim Type Taxonomy below
  requires: list[claim_id] # Claims that must precede this one
  provides: list[string]   # What this claim makes available to downstream nodes
  section: string          # Section identifier: §1, §2, ...
  register: enum           # See Register Types below
  weight: enum             # STRUCTURAL | SUPPORTING | DECORATIVE
  thread: list[string]     # Thread identifiers this claim participates in
  status: enum             # PLANNED | DRAFTED | VALIDATED
```

### Claim Type Taxonomy

| Type | Definition | Graph Behaviour |
|---|---|---|
| THESIS | The document's central argument or purpose statement | Root node. Maximum 1–2 per document. All other nodes ultimately serve this. |
| PREMISE | A foundational assertion that supports the thesis | Must connect to THESIS directly or through other PREMISE nodes. |
| EVIDENCE | Specific data, example, or citation supporting a premise | Must connect to at least one PREMISE. Cannot float independently. |
| SYNTHESIS | Combines two or more prior claims into a new insight | Must have ≥2 inbound edges. Produces a novel claim not present in its inputs. |
| TRANSITION | Bridges two sections or argument phases | Must have exactly 1 inbound and 1 outbound edge. Cannot carry substantive claims. |
| FRAMING | Establishes interpretive lens, context, or scope | Typically appears in opening and closing sections. Constrains how other nodes are read. |
| CONCESSION | Acknowledges a counterpoint or limitation | Must connect to the claim it qualifies. Strengthens rather than undermines the argument. |
| REBUTTAL | Responds to a concession or anticipated objection | Must have inbound edge from a CONCESSION node. |

### Weight Classification

- **STRUCTURAL:** Removing this node breaks the argument's logical chain. The
  document cannot function without it.
- **SUPPORTING:** Removing this node weakens but does not break the argument.
  The reader loses depth but retains the core logic.
- **DECORATIVE:** Removing this node has no logical impact. It exists for
  rhetorical texture, style, or reader engagement. Not inherently bad — but
  if the document has coherence problems, decorative nodes are the first to
  cut or relocate.

---

## Edge Schema — Discourse Relations

Edges connect claim nodes. Every edge must carry a typed discourse relation.

```yaml
edge:
  source: claim_id
  target: claim_id
  relation: enum          # See discourse-relations.md for full taxonomy
  strength: enum          # NECESSARY | SUPPORTING | WEAK
  direction: enum         # FORWARD | BACKWARD | BIDIRECTIONAL
  explicit: boolean       # Is this relation stated in the prose or only implied?
```

### Edge Strength

- **NECESSARY:** Removing this edge makes the target node incomprehensible.
  The reader cannot understand the target without first receiving the source.
- **SUPPORTING:** The target is clearer with this edge but survives without it.
  The reader can fill the gap with reasonable inference.
- **WEAK:** The connection exists but is not load-bearing. Often decorative
  or habitual ("As we saw earlier...").

### Edge Validation Rules

1. Every non-THESIS node must have at least one inbound edge
2. Every non-terminal node must have at least one outbound edge
3. No cycles (A→B→C→A) — except in explicitly dialectical structures
4. TRANSITION nodes: exactly 1 inbound, 1 outbound
5. EVIDENCE nodes: cannot have outbound edges to PREMISE nodes (evidence
   supports premises, not the reverse)
6. If `explicit: false`, flag for review — implicit relations are coherence
   risks

---

## Section Contract Schema

```yaml
section_contract:
  section_id: string       # §1, §2, ...
  title: string
  receives: list[string]   # Reader knowledge inherited from prior sections
  establishes: list[claim_id]  # Claims introduced in this section
  delivers: list[string]   # Reader knowledge available to subsequent sections
  register: enum
  active_threads: list[string]  # Threads that must be maintained or advanced
  resolves_threads: list[string]  # Threads that reach conclusion here
  introduces_threads: list[string]  # New threads starting here
```

### Contract Validation Rules

1. Every item in `receives` must appear in some prior section's `delivers`
2. Every item in `delivers` must trace to a claim in `establishes`
3. `active_threads` must be a subset of threads introduced in prior sections
   that haven't been resolved
4. No section may resolve a thread it didn't receive as active
5. The final section's `delivers` must satisfy the document's stated purpose

---

## Thread Schema

```yaml
thread:
  thread_id: string        # T1, T2, ...
  label: string            # Human-readable: "reliability argument", "cost narrative"
  introduced_in: string    # Section ID
  developed_in: list[string]  # Section IDs where this thread advances
  resolved_in: string      # Section ID where this thread concludes (or "UNRESOLVED")
  claim_ids: list[claim_id]  # All claims participating in this thread
  register: enum           # Must be consistent across all participating sections
```

### Thread Validation Rules

1. Every thread must be introduced before it can be developed or resolved
2. Every thread must be either resolved or explicitly marked UNRESOLVED
   with justification
3. No section may develop a thread that hasn't been introduced
4. Thread register must be consistent — shifts require explicit marking
5. Gap detection: if a thread skips more than one consecutive section,
   flag for reader-continuity risk

---

## Register Types

| Register | Markers | Appropriate For |
|---|---|---|
| FORMAL_LEGAL | Precise terminology, passive voice, defined terms, provision references | Legal submissions, statutory analysis |
| FORMAL_ACADEMIC | Hedged claims, citation-heavy, discipline-specific vocabulary | Research papers, academic essays |
| FORMAL_BUSINESS | Direct, active voice, outcome-oriented, minimal hedging | Reports, proposals, memos |
| TECHNICAL | Jargon-dense, assumed expertise, specification-style | Documentation, technical guides |
| EXPLANATORY | Progressive complexity, analogies, defined terms introduced gently | Tutorials, explainers, educational content |
| NARRATIVE | Story structure, scene-setting, character/event focus | Case studies, narrative non-fiction |
| CONVERSATIONAL | Contractions, direct address, informal connectives | Blog posts, casual writing |
| DIRECTIVE | Imperative verbs, short sentences, action-oriented | Instructions, procedures, skill files |

### Register Consistency Rules

- Each section declares its register in the section contract
- Register shifts between sections must be mapped and justified
- Register shifts *within* a section are coherence failures unless the
  section is explicitly multi-register (e.g., a technical section that
  opens with a narrative hook)
- FRAMING nodes typically set the register for their section

---

## Graph-Level Validation Checklist

Run before any prose generation:

- [ ] Exactly 1–2 THESIS nodes exist
- [ ] Every non-THESIS node has ≥1 inbound edge
- [ ] No orphaned nodes (nodes with zero edges)
- [ ] No cycles in the dependency graph
- [ ] Every section contract's `receives` items are satisfied
- [ ] Every thread is introduced → developed → resolved (or marked UNRESOLVED)
- [ ] No thread gaps exceed one section
- [ ] Register is consistent within each section
- [ ] Register shifts between sections are justified
- [ ] TRANSITION nodes have exactly 1 inbound and 1 outbound edge
- [ ] EVIDENCE nodes connect to PREMISE nodes, not the reverse
- [ ] All implicit edges (`explicit: false`) are flagged for review
- [ ] Final section's `delivers` satisfies document purpose
