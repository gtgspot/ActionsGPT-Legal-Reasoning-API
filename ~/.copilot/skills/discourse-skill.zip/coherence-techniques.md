# Coherence Techniques

Practical methods for building and maintaining discourse coherence in
long-form output. These are construction tools, not diagnostic tools —
use them during PRE-WRITE mode to build coherent structure from the
ground up.

---

## Technique 1: Backward Graph Construction

Build the coherence graph *backwards* from the conclusion.

**Why:** Forward construction ("I'll start with background, then...") 
produces exploratory writing that discovers its argument as it goes. This
is how most incoherent documents happen. Backward construction forces
every section to justify its existence against the conclusion.

**Method:**
1. State the document's final conclusion or call to action
2. Ask: "What must the reader believe/understand for this conclusion to land?"
3. Each answer becomes a PREMISE node. Repeat step 2 for each premise.
4. Continue until you reach claims the reader already holds (BACKGROUND)
   or claims that can be established with EVIDENCE
5. The completed backward chain is the coherence graph — reverse it for
   reading order

**When to use:** Argumentative, persuasive, or analytical documents where
the conclusion is known in advance. Not suitable for exploratory or
narrative writing.

---

## Technique 2: Thread Braiding

Manage multiple argument lines that must coexist in a single document
without tangling.

**Why:** Documents often carry 2–4 threads (e.g., a technical thread, a
cost thread, and a risk thread in a proposal). Without explicit braiding,
threads collide — a paragraph starts on cost, drifts into technical
detail, and returns to cost with an implicit assumption the reader
followed the technical detour.

**Method:**
1. Identify all threads the document must carry (T1, T2, T3...)
2. For each section, declare which threads are active
3. Rule: maximum 2 threads active per section. If a section needs 3+
   threads, split it.
4. When switching active threads between sections, use a TRANSITION node
   that explicitly hands off: "Having established X [Thread A conclusion],
   we now turn to Y [Thread B introduction]."
5. Map the braid visually:

```
§1:  T1──────────T2
§2:  T1           T2──────
§3:       T1──────T2
§4:  T1──────────      T3
§5:       T1──────T3
§6:  T1──T2──T3  (synthesis)
```

**When to use:** Any document with multiple argument lines, especially
proposals, reports, and legal submissions.

---

## Technique 3: Section Contracts Protocol

Define explicit input/output contracts for every section before writing it.

**Why:** Without contracts, sections bleed into each other. Section 2
quietly assumes something Section 1 never established. Section 4 repeats
what Section 3 already delivered because there's no record of what's
been covered.

**Method:**

For each section, write a contract card before drafting:

```
Section §3 — Risk Analysis
RECEIVES: Reader has accepted the proposed architecture (from §2)
          Reader understands the cost envelope (from §2)
ESTABLISHES: Three risk categories with likelihood/impact
             Mitigation strategy for each
             Residual risk after mitigation
DELIVERS: Reader can evaluate whether residual risks are acceptable
REGISTER: Formal business
ACTIVE THREADS: T1 (architecture), T3 (risk) — T2 (cost) paused
TRANSITION IN: "The architecture above introduces three categories of risk."
TRANSITION OUT: "With these mitigations in place, the implementation
timeline becomes..."
```

**Validation test:** Can you read only the contract cards, in order, and
understand the document's logical flow without reading any prose? If yes,
the contracts are well-formed.

**When to use:** Always. This is the core technique. Every other technique
supplements this one.

---

## Technique 4: Transition Engineering

Build transitions that carry structural load, not just connecting tissue.

**Why:** Most transitions are cosmetic — "Moving on to...", "Another
consideration is...", "It is also worth noting...". These create the
*illusion* of connection without actually connecting. A structural
transition advances the argument across the section boundary.

**Method — The Three-Part Transition:**

1. **Anchor:** Reference the deliverable from the preceding section
   (what the reader now knows)
2. **Bridge:** State the logical relation between sections (why we move
   from A to B)
3. **Launch:** Introduce the receiving section's first claim

**Pattern:**
```
[Anchor] Having established that the current system cannot scale
beyond 10k concurrent users,
[Bridge] the question becomes what architecture would remove this
ceiling.
[Launch] A microservices decomposition along domain boundaries
offers three specific advantages.
```

**Anti-patterns (do not use):**
- "Moving on to the next section..." — no logical content
- "Another important consideration is..." — implies parallel when the
  relation might be causal or contrastive
- "It should also be noted that..." — hedging that weakens the claim
  before it's even made
- Starting a new section with no transition at all — forces the reader
  to infer the connection

**When to use:** Every section boundary. No exceptions.

---

## Technique 5: Register Locking

Maintain consistent register within sections, manage deliberate shifts
between sections.

**Why:** Register breaks are the most *felt* but least *identified*
coherence failure. The reader senses something is "off" without being
able to say what. A formal legal analysis section that suddenly uses
"basically" or "kind of" breaks trust. A conversational blog post that
shifts into passive academic voice loses engagement.

**Method:**
1. Declare register per section in the section contract
2. Before drafting, list 3–5 register markers for the declared register:
   - Formal legal: "pursuant to", "the Court held", "it is submitted"
   - Technical: "implements", "returns", "the function accepts"
   - Conversational: "here's the thing", "you might notice", "basically"
3. During generation, test each sentence: does it contain markers from
   a *different* register than declared?
4. If a register shift is intentional (e.g., a narrative hook opening a
   technical section), mark it in the section contract and keep it to
   ≤2 sentences before returning to the declared register

**When to use:** Any document longer than 500 words. Shorter pieces
rarely have register problems.

---

## Technique 6: Claim Dependency Testing

Stress-test the coherence graph by simulating removal of each node.

**Why:** The graph might look connected but contain nodes that don't
actually carry weight. This test reveals which claims are structurally
necessary and which are decorative.

**Method:**
1. For each claim node, mentally remove it from the graph
2. Ask three questions:
   - Does the argument from surrounding nodes still hold?
   - Does any downstream node become unsupported?
   - Does any thread lose continuity?
3. Classify the node:
   - If removal breaks the argument → STRUCTURAL (keep, strengthen)
   - If removal weakens but doesn't break → SUPPORTING (keep, but
     deprioritise in space-constrained documents)
   - If removal has no effect → DECORATIVE (consider cutting, or
     acknowledge it serves rhetorical rather than logical purpose)

**When to use:** After building the graph, before writing. Also useful
in POST-AUDIT mode to identify bloat.

---

## Technique 7: Coherence Checkpointing

Validate coherence at defined intervals during long-form generation.

**Why:** Coherence degrades gradually during generation. By paragraph
ten, the framing from paragraph one has drifted. Checkpoints catch
drift before it compounds.

**Method:**
1. Set checkpoint intervals based on document length:
   - 500–1500 words: checkpoint every section
   - 1500–3000 words: checkpoint every 2–3 sections
   - 3000+ words: checkpoint every section + a mid-document full review
2. At each checkpoint, verify:
   - Current section's contract is being fulfilled
   - Active threads are being maintained (not dropped or drifted)
   - Register is consistent with declaration
   - No claims have been introduced that aren't in the graph
   - Transitions from the previous checkpoint are structurally sound
3. If a checkpoint fails, stop generation and repair before continuing

**When to use:** Every long-form generation. This is not optional — it
is the runtime enforcement mechanism for the coherence graph.
