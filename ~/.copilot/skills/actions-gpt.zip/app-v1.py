import base64, re, uuid
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, AnyUrl
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="ActionsGPT — Legal Reasoning API", version="1.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["Authorization","Content-Type"])

DOCS = {}
class FileItem(BaseModel): filename: str; media_type: str; content_base64: str
class Ingest(BaseModel):
    title: str; urls: list[AnyUrl]|None=None; files: list[FileItem]|None=None; canonicalize: bool=True
class Status(BaseModel): doc_id: str; status: str
class FetchReq(BaseModel): url: AnyUrl

@app.post("/documents/ingest", response_model=Status)
def ingest(req: Ingest):
    doc_id = str(uuid.uuid4())
    text = ""
    if req.files:
        for f in req.files:
            raw = base64.b64decode(f.content_base64)
            text += raw.decode("utf-8", "ignore") if not re.search("pdf", f.media_type, re.I) else f"[PDF {len(raw)} bytes]\\
"
    if req.urls:
        text += "\\
".join(map(str, req.urls))
    DOCS[doc_id] = {"status":"ready","text":text}
    return Status(doc_id=doc_id, status="ready")

@app.get("/documents/{doc_id}/status", response_model=Status)
def status(doc_id: str):
    if doc_id not in DOCS: raise HTTPException(404, "doc not found")
    return Status(doc_id=doc_id, status=DOCS[doc_id]["status"])

@app.post("/sources/fetch")
async def fetch(body: FetchReq, authorization: str|None = Header(default=None)):
    # In Spaces, outbound fetches are allowed; forward Authorization if present.
    import httpx
    headers = {"User-Agent":"ActionsGPT/1.1"}
    if authorization: headers["Authorization"]=authorization
    async with httpx.AsyncClient(follow_redirects=True, timeout=30) as c:
        r = await c.get(str(body.url), headers=headers)
        if r.status_code == 401: raise HTTPException(401, "Upstream auth required/invalid")
        r.raise_for_status()
        return {"source":{"title":str(body.url), "uri":str(body.url)}, "text":r.text[:50000], "metadata":{"content_type":r.headers.get("content-type","")}}
