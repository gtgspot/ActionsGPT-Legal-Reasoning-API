# app.py
import base64, hashlib, os, re, uuid
from typing import Optional, List, Literal
from datetime import datetime
from fastapi import FastAPI, Body, Header, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, AnyUrl
import httpx

app = FastAPI(title="ActionsGPT — Legal Reasoning API", version="1.1.0")

# === CORS for ChatGPT Actions ===
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten later if you wish
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["Authorization", "Content-Type", "*"],
)

# === In-memory demo store (swap for a DB/S3) ===
DOCS = {}

# ---------- Schemas (subset) ----------
class FileItem(BaseModel):
    filename: str
    media_type: str
    content_base64: str

class DocumentIngestRequest(BaseModel):
    title: str
    jurisdiction_hint: Optional[Literal["VIC","NSW","QLD","SA","WA","TAS","NT","ACT","CTH","NZ","UK","US","EU","OTHER"]] = None
    matter_type: Optional[str] = None
    files: Optional[List[FileItem]] = None
    urls: Optional[List[AnyUrl]] = None
    ocr_language_hints: Optional[List[str]] = None
    canonicalize: bool = True

class DocumentIngestResponse(BaseModel):
    doc_id: str
    status: Literal["queued","processing","ready"]

class SourceRef(BaseModel):
    source_id: str
    title: str
    uri: Optional[AnyUrl] = None
    jurisdiction: Optional[str] = None
    type: Optional[str] = None
    date: Optional[datetime] = None
    pinpoint: Optional[str] = None
    quote_range: Optional[str] = None
    reliability_score: Optional[float] = Field(default=0.8, ge=0, le=1)

# ---------- Helpers ----------
PDF_RX = re.compile(r"application/(pdf|x-pdf)", re.I)

async def fetch_text(url: str, auth_header: Optional[str]) -> str:
    # Pass through Authorization when present (GitHub/HF private resources)
    headers = {"User-Agent": "ActionsGPT/1.1"}
    if auth_header:
        headers["Authorization"] = auth_header

    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        r = await client.get(url, headers=headers)
        if r.status_code == 401:
            raise HTTPException(status_code=401, detail="Upstream auth required/invalid")
        r.raise_for_status()
        ctype = r.headers.get("content-type", "")
        # Minimal normalization; extend with proper HTML->text, PDF OCR, etc.
        if "text/" in ctype or "json" in ctype:
            return r.text
        if "pdf" in ctype:
            return f"[PDF {len(r.content)} bytes fetched — parse/ocr downstream]"
        return r.text if r.text else f"[binary {len(r.content)} bytes]"

def normalize_files(files: Optional[List[FileItem]]) -> str:
    if not files:
        return ""
    texts = []
    for f in files:
        raw = base64.b64decode(f.content_base64)
        if PDF_RX.search(f.media_type):
            texts.append(f"[PDF {f.filename} {len(raw)} bytes — parse/ocr downstream]")
        else:
            try:
                texts.append(raw.decode("utf-8", errors="ignore"))
            except Exception:
                texts.append(f"[binary {f.filename} {len(raw)} bytes]")
    return "\\
\\
".join(texts)

# ---------- Routes ----------
@app.post("/documents/ingest", response_model=DocumentIngestResponse)
async def ingest_documents(req: DocumentIngestRequest):
    doc_id = str(uuid.uuid4())
    # Very light “processing” demo; replace with a background job
    text_blob = normalize_files(req.files) if req.files else ""
    if req.urls:
        text_blob += "\\
\\
" + "\\
\\
".join(req.urls)
    DOCS[doc_id] = {
        "title": req.title,
        "status": "ready",  # set "processing" if you add async pipeline
        "content": text_blob.strip(),
        "meta": req.model_dump(),
        "created": datetime.utcnow().isoformat()
    }
    return DocumentIngestResponse(doc_id=doc_id, status=DOCS[doc_id]["status"])

@app.get("/documents/{doc_id}/status", response_model=DocumentIngestResponse)
async def get_document_status(doc_id: str):
    if doc_id not in DOCS:
        raise HTTPException(status_code=404, detail="doc not found")
    return DocumentIngestResponse(doc_id=doc_id, status=DOCS[doc_id]["status"])

class FetchReq(BaseModel):
    url: AnyUrl
    respect_robots: bool = True
    format_hint: Literal["html","pdf","text","json","dataset","auto"] = "auto"

@app.post("/sources/fetch")
async def fetch_external_source(
    body: FetchReq,
    authorization: Optional[str] = Header(default=None),
):
    """
    - For GitHub URLs: ChatGPT will attach an OAuth bearer token if your Action declares GitHub OAuth.
    - For Hugging Face URLs: ChatGPT will attach HF token (Bearer) if configured.
    - For public URLs: call proceeds without Authorization.
    """
    text = await fetch_text(str(body.url), authorization)
    src = SourceRef(
        source_id=hashlib.sha1(str(body.url).encode()).hexdigest()[:16],
        title=str(body.url),
        uri=str(body.url),
        type="dataset" if "huggingface.co/datasets" in str(body.url) else "other",
        reliability_score=0.8,
    )
    return {"source": src.model_dump(), "text": text, "metadata": {"format_hint": body.format_hint}}
